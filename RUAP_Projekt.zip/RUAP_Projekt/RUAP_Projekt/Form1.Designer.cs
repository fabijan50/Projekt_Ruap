﻿
namespace RUAP_Projekt
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.textBoxPh_Value = new System.Windows.Forms.TextBox();
			this.textBoxHardness_Value = new System.Windows.Forms.TextBox();
			this.textBoxSolids_Value = new System.Windows.Forms.TextBox();
			this.textBoxChloramines_Value = new System.Windows.Forms.TextBox();
			this.textBoxSulfate_Value = new System.Windows.Forms.TextBox();
			this.textBoxConductivity_Value = new System.Windows.Forms.TextBox();
			this.textBoxOrganicCarbon_Value = new System.Windows.Forms.TextBox();
			this.textBoxTrihalomethanes_Value = new System.Windows.Forms.TextBox();
			this.textBoxTurbidity_Value = new System.Windows.Forms.TextBox();
			this.buttonRandom = new System.Windows.Forms.Button();
			this.buttonGetResults = new System.Windows.Forms.Button();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(40, 57);
			this.textBox2.Name = "textBox2";
			this.textBox2.ReadOnly = true;
			this.textBox2.Size = new System.Drawing.Size(100, 20);
			this.textBox2.TabIndex = 1;
			this.textBox2.Text = "Hardness";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(40, 92);
			this.textBox3.Name = "textBox3";
			this.textBox3.ReadOnly = true;
			this.textBox3.Size = new System.Drawing.Size(100, 20);
			this.textBox3.TabIndex = 2;
			this.textBox3.Text = "Solids";
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(40, 127);
			this.textBox4.Name = "textBox4";
			this.textBox4.ReadOnly = true;
			this.textBox4.Size = new System.Drawing.Size(100, 20);
			this.textBox4.TabIndex = 3;
			this.textBox4.Text = "Chloramines";
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(40, 162);
			this.textBox5.Name = "textBox5";
			this.textBox5.ReadOnly = true;
			this.textBox5.Size = new System.Drawing.Size(100, 20);
			this.textBox5.TabIndex = 4;
			this.textBox5.Text = "Sulfate";
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(40, 197);
			this.textBox6.Name = "textBox6";
			this.textBox6.ReadOnly = true;
			this.textBox6.Size = new System.Drawing.Size(100, 20);
			this.textBox6.TabIndex = 5;
			this.textBox6.Text = "Conductivity";
			// 
			// textBox7
			// 
			this.textBox7.Location = new System.Drawing.Point(40, 232);
			this.textBox7.Name = "textBox7";
			this.textBox7.ReadOnly = true;
			this.textBox7.Size = new System.Drawing.Size(100, 20);
			this.textBox7.TabIndex = 6;
			this.textBox7.Text = "Organic carbon";
			// 
			// textBox8
			// 
			this.textBox8.Location = new System.Drawing.Point(40, 267);
			this.textBox8.Name = "textBox8";
			this.textBox8.ReadOnly = true;
			this.textBox8.Size = new System.Drawing.Size(100, 20);
			this.textBox8.TabIndex = 7;
			this.textBox8.Text = "Trihalomethanes";
			// 
			// textBox9
			// 
			this.textBox9.Location = new System.Drawing.Point(40, 303);
			this.textBox9.Name = "textBox9";
			this.textBox9.ReadOnly = true;
			this.textBox9.Size = new System.Drawing.Size(100, 20);
			this.textBox9.TabIndex = 8;
			this.textBox9.Text = "Turbidity";
			// 
			// textBoxPh_Value
			// 
			this.textBoxPh_Value.Location = new System.Drawing.Point(146, 22);
			this.textBoxPh_Value.Name = "textBoxPh_Value";
			this.textBoxPh_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxPh_Value.TabIndex = 10;
			this.textBoxPh_Value.Text = "1";
			// 
			// textBoxHardness_Value
			// 
			this.textBoxHardness_Value.Location = new System.Drawing.Point(146, 57);
			this.textBoxHardness_Value.Name = "textBoxHardness_Value";
			this.textBoxHardness_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxHardness_Value.TabIndex = 11;
			this.textBoxHardness_Value.Text = "1";
			// 
			// textBoxSolids_Value
			// 
			this.textBoxSolids_Value.Location = new System.Drawing.Point(146, 92);
			this.textBoxSolids_Value.Name = "textBoxSolids_Value";
			this.textBoxSolids_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxSolids_Value.TabIndex = 12;
			this.textBoxSolids_Value.Text = "1";
			// 
			// textBoxChloramines_Value
			// 
			this.textBoxChloramines_Value.Location = new System.Drawing.Point(146, 127);
			this.textBoxChloramines_Value.Name = "textBoxChloramines_Value";
			this.textBoxChloramines_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxChloramines_Value.TabIndex = 13;
			this.textBoxChloramines_Value.Text = "1";
			// 
			// textBoxSulfate_Value
			// 
			this.textBoxSulfate_Value.Location = new System.Drawing.Point(146, 162);
			this.textBoxSulfate_Value.Name = "textBoxSulfate_Value";
			this.textBoxSulfate_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxSulfate_Value.TabIndex = 14;
			this.textBoxSulfate_Value.Text = "1";
			// 
			// textBoxConductivity_Value
			// 
			this.textBoxConductivity_Value.Location = new System.Drawing.Point(146, 197);
			this.textBoxConductivity_Value.Name = "textBoxConductivity_Value";
			this.textBoxConductivity_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxConductivity_Value.TabIndex = 15;
			this.textBoxConductivity_Value.Text = "1";
			// 
			// textBoxOrganicCarbon_Value
			// 
			this.textBoxOrganicCarbon_Value.Location = new System.Drawing.Point(146, 232);
			this.textBoxOrganicCarbon_Value.Name = "textBoxOrganicCarbon_Value";
			this.textBoxOrganicCarbon_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxOrganicCarbon_Value.TabIndex = 16;
			this.textBoxOrganicCarbon_Value.Text = "1";
			// 
			// textBoxTrihalomethanes_Value
			// 
			this.textBoxTrihalomethanes_Value.Location = new System.Drawing.Point(146, 267);
			this.textBoxTrihalomethanes_Value.Name = "textBoxTrihalomethanes_Value";
			this.textBoxTrihalomethanes_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxTrihalomethanes_Value.TabIndex = 17;
			this.textBoxTrihalomethanes_Value.Text = "1";
			// 
			// textBoxTurbidity_Value
			// 
			this.textBoxTurbidity_Value.Location = new System.Drawing.Point(146, 303);
			this.textBoxTurbidity_Value.Name = "textBoxTurbidity_Value";
			this.textBoxTurbidity_Value.Size = new System.Drawing.Size(100, 20);
			this.textBoxTurbidity_Value.TabIndex = 18;
			this.textBoxTurbidity_Value.Text = "1";
			// 
			// buttonRandom
			// 
			this.buttonRandom.Location = new System.Drawing.Point(40, 334);
			this.buttonRandom.Name = "buttonRandom";
			this.buttonRandom.Size = new System.Drawing.Size(206, 92);
			this.buttonRandom.TabIndex = 20;
			this.buttonRandom.Text = "Random";
			this.buttonRandom.UseVisualStyleBackColor = true;
			this.buttonRandom.Click += new System.EventHandler(this.buttonRandom_Click);
			// 
			// buttonGetResults
			// 
			this.buttonGetResults.Location = new System.Drawing.Point(305, 334);
			this.buttonGetResults.Name = "buttonGetResults";
			this.buttonGetResults.Size = new System.Drawing.Size(470, 92);
			this.buttonGetResults.TabIndex = 22;
			this.buttonGetResults.Text = "Get Results";
			this.buttonGetResults.UseVisualStyleBackColor = true;
			this.buttonGetResults.Click += new System.EventHandler(this.buttonGetResults_Click);
			// 
			// richTextBox1
			// 
			this.richTextBox1.Location = new System.Drawing.Point(305, 22);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.Size = new System.Drawing.Size(470, 292);
			this.richTextBox1.TabIndex = 23;
			this.richTextBox1.Text = "";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(40, 22);
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.Size = new System.Drawing.Size(100, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "ph";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.buttonGetResults);
			this.Controls.Add(this.buttonRandom);
			this.Controls.Add(this.textBoxTurbidity_Value);
			this.Controls.Add(this.textBoxTrihalomethanes_Value);
			this.Controls.Add(this.textBoxOrganicCarbon_Value);
			this.Controls.Add(this.textBoxConductivity_Value);
			this.Controls.Add(this.textBoxSulfate_Value);
			this.Controls.Add(this.textBoxChloramines_Value);
			this.Controls.Add(this.textBoxSolids_Value);
			this.Controls.Add(this.textBoxHardness_Value);
			this.Controls.Add(this.textBoxPh_Value);
			this.Controls.Add(this.textBox9);
			this.Controls.Add(this.textBox8);
			this.Controls.Add(this.textBox7);
			this.Controls.Add(this.textBox6);
			this.Controls.Add(this.textBox5);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.TextBox textBox9;
		private System.Windows.Forms.TextBox textBoxPh_Value;
		private System.Windows.Forms.TextBox textBoxHardness_Value;
		private System.Windows.Forms.TextBox textBoxSolids_Value;
		private System.Windows.Forms.TextBox textBoxChloramines_Value;
		private System.Windows.Forms.TextBox textBoxSulfate_Value;
		private System.Windows.Forms.TextBox textBoxConductivity_Value;
		private System.Windows.Forms.TextBox textBoxOrganicCarbon_Value;
		private System.Windows.Forms.TextBox textBoxTrihalomethanes_Value;
		private System.Windows.Forms.TextBox textBoxTurbidity_Value;
		private System.Windows.Forms.Button buttonRandom;
		private System.Windows.Forms.Button buttonGetResults;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.TextBox textBox1;
	}
}

